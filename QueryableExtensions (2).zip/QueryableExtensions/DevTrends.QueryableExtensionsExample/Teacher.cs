﻿using System.Collections.Generic;

namespace DevTrends.QueryableExtensionsExample
{
    public class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<Student> Students { get; set; }
    }
}
