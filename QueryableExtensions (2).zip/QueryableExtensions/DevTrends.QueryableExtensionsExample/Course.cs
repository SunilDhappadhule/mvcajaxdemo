﻿using System.Collections.Generic;

namespace DevTrends.QueryableExtensionsExample
{
    public class Course
    {
        public Course()
        {
            Students = new List<Student>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public ICollection<Student> Students { get; set; }
    }
}
