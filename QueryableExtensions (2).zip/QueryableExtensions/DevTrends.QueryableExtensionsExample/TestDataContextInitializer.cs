﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace DevTrends.QueryableExtensionsExample
{
    public class TestDataContextInitializer : DropCreateDatabaseIfModelChanges<StudentContext>
    {
        protected override void Seed(StudentContext context)
        {
            var courses = new List<Course>
            {
                new Course { Description = "Maths" },
                new Course { Description = "English" },
                new Course { Description = "Physics" },
                new Course { Description = "French" },
                new Course { Description = "History" }
            };

            var students = new List<Student>
            {
                new Student{ FirstName = "Dave", LastName="Lowe", DateOfBirth = new DateTime(2000, 1, 1), Tutor = new Teacher { Name = "Mr Smith" } },
                new Student { FirstName = "Mike", LastName = "Davies", DateOfBirth = new DateTime(2000, 5, 21), Tutor = new Teacher { Name = "Mrs Jones" } },
                new Student { FirstName = "Kelly", LastName = "Williams", DateOfBirth = new DateTime(2000, 3, 6), Tutor = new Teacher { Name = "Dr Nobel" } }
            };

            courses.ForEach(course => students[0].Courses.Add(course));
            courses.Take(3).ToList().ForEach(course => students[1].Courses.Add(course));
            students[2].Courses.Add(courses[0]);

            students.ForEach(student => context.Students.Add(student));
            courses.ForEach(course => context.Courses.Add(course));

            context.SaveChanges();
        }
    }
}
