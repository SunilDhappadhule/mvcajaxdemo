﻿
namespace DevTrends.QueryableExtensionsExample
{
    public class StudentSummary
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NotADatabaseColumn { get; set; }
        public string TutorName { get; set; }
        public int CoursesCount { get; set; }

        public string FullName
        {
            get { return string.Format("{0} {1}", FirstName, LastName); }
        }
    }
}
