﻿using System.Data.Entity;

namespace DevTrends.QueryableExtensionsExample
{
    public class StudentContext : DbContext
    {
        public DbSet<Course> Courses { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
    }
}
