﻿using System;
using System.Collections.Generic;

namespace DevTrends.QueryableExtensionsExample
{
    public class Student
    {
        public Student()
        {
            Courses = new List<Course>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public ICollection<Course> Courses { get; set; }
        public Teacher Tutor { get; set; }
    }
}
