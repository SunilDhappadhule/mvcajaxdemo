﻿using System.Collections.Generic;

namespace DevTrends.QueryableExtensionsExample
{
    public class AnotherStudentSummary
    {
        public AnotherStudentSummary()
        {
            Courses = new List<Course>();
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public ICollection<Course> Courses { get; set; }
    }
}
